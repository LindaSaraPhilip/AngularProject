import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators  } from '@angular/forms';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  activeStatus:any='now'

  presentDate = new Date(); 
 constructor(private fb:FormBuilder)
  {

  }
  submit=false
  registrationForm=this.fb.group(
  {
    firstName:['hello',Validators.required],
    lastName:['',Validators.required],
    phone:['',[Validators.required,Validators.pattern('[0-9]{10}')]],
    email:['',[Validators.required,Validators.email]]
  })
  
  ngOnInit()
  {
    new Observable((observer)=>{
      setTimeout(() => {
        observer.next('1 min ago')
      }, 60000);
      setTimeout(() => {
        observer.next('2 min ago')
      }, 120000);
      setTimeout(() => {
        observer.next('3 min ago')
       
      }, 180000);
      setTimeout(() => {
        observer.next('4 min ago')
        
      }, 240000);
      setTimeout(() => {
        observer.next('30 min ago')
        observer.complete();
      }, 1800000 );
     
    }).subscribe((res =>{
      this.activeStatus=res
    }))
    
  }
  get f()
  {
    return this.registrationForm.controls;
  }
  onSubmit()
  {
    this.submit=true
    console.log("Clicked")
    console.log("f",this.f);
  }

  
}



import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  constructor(private fb:FormBuilder,private router:Router)
  {

  }
  
  submit=false
  registrationForm=this.fb.group(
  {
    Name:['',Validators.required],
    accountno:['',Validators.required],
    branch:['',Validators.required],
    bank:['',Validators.required],
    ifsc:['',Validators.required],
    type:['',Validators.required],
    email:['',[Validators.required,Validators.email]],
    amount:['',Validators.required],
  })
  fullName: string = "Hello JavaTpoint";    
  public flag="even"
  public c=0;
  public Str="";
  public Strr=""
  public count=0
  public is_hidden=true
  ngOnInit()
  {
    
    
  }
  get f()
  {
    return this.registrationForm.controls;
  }
  onSubmit()
  {
    this.submit=true
    console.log("Clicked")
    console.log("f",this.f);
    //alert("Money Transfer - SUCCESS")
  }
  gotoHome()
  {
    this.router.navigate(['home'])
  }
  
  gotoStatus2()
  {
   
    if(this.registrationForm.valid)
    {
    confirm("Do you want to save changes?")
    if (confirm("Do you want to save changes?") === true) 
    {
      alert("Data saved successfully! Please verify the amount again   ");
      this.router.navigate(['depositstatus'])
    
    } 
    else
  {
    alert("Save Cancelled");
  }
}
else{
  alert("Enter Required Fields");
}
  }
 
}


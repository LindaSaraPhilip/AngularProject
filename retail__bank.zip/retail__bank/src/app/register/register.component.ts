import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private fb:FormBuilder,private router:Router) { }

  submit=false
  registrationForm=this.fb.group(
  {
    firstName:['',Validators.required],
    lastName:['',Validators.required],
    phone:['',[Validators.required,Validators.pattern('[0-9]{10}')]],
    email:['',[Validators.required,Validators.email]]
  })
  
  ngOnInit()
  {
    
    
  }
  get f()
  {
    return this.registrationForm.controls;
  }
  onSubmit()
  {
    this.submit=true
    console.log("Clicked")
    console.log("f",this.f);
    //alert("you cannot access TechBank without filling required fields")
  }
  gotoStatus1()
  {
    
    alert("A one time password is generated on your phone .please login and then change accordingly")
    this.router.navigate(['login'])

  }
}


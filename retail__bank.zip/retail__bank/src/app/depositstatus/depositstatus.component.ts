import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-depositstatus',
  templateUrl: './depositstatus.component.html',
  styleUrls: ['./depositstatus.component.css']
})
export class DepositstatusComponent implements OnInit {
  fullName: string = "Hello JavaTpoint";    
  public flag="even"
  public c=0;
  public Str="";
  public Strr=""
  public count=0
  public is_hidden=true

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  check()
  {
    this.is_hidden=false
    if(this.count % 2 ==0)
    {
      this.Strr= " amount deposited successfully"
    }
    else
    {
      this.Strr="amount deposited successfully"
    }
  }
  clear()
  {
    this.is_hidden=true
  }
  gotoHome()
  {
    this.router.navigate(['home'])
  }


}

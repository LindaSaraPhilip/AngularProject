import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-accountsummary',
  templateUrl: './accountsummary.component.html',
  styleUrls: ['./accountsummary.component.css']
})
export class AccountsummaryComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  public accounts=[
    {"PostDate":"2016-10-29","Description":"Deposit to Primary Account","Type":"Primary","Status":"Finished","Amount":500,"AvailableAmount":10000},
    {"PostDate":"2016-11-20","Description":"Deposit to Primary Account","Type":"Primary","Status":"Finished","Amount":1000,"AvailableAmount":11000},
    {"PostDate":"2017-5-29","Description":"Deposit to Savings Account","Type":"Savings","Status":"Finished","Amount":5000,"AvailableAmount":7000},
    {"PostDate":"2020-10-29","Description":"Deposit to Savings Account","Type":"Savings","Status":"Finished","Amount":2000,"AvailableAmount":9000},
    {"PostDate":"2020-12-14","Description":"Deposit to Primary Account","Type":"Primary","Status":"Finished","Amount":3000,"AvailableAmount":14000},
    {"PostDate":"2021-3-29","Description":"Deposit to Primary Account","Type":"Primary","Status":"Finished","Amount":1000,"AvailableAmount":15000},
    {"PostDate":"2021-5-14","Description":"Withdrawal from Savings Account","Type":"Savings","Status":"Finished","Amount":2000,"AvailableAmount":7000}
    
    
  ]
  gotoHome()
  {
    this.router.navigate(['home'])
  }
 

}

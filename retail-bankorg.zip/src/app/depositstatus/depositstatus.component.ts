import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-depositstatus',
  templateUrl: './depositstatus.component.html',
  styleUrls: ['./depositstatus.component.css']
})
export class DepositstatusComponent implements OnInit {
  fullName: string = "Hello JavaTpoint";    
  public flag="even"
  public c=0;
  public Str="";
  public Strr=""
  public count=0
  public is_hidden=true

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  check()
  {
    this.is_hidden=false
    if(this.count < 1000000)
    {
      this.Strr= " amount deposited successfully"
      alert("The amount has been credited successfully to TechBank")
    }
    else
    {
      this.Strr="Money is not credited to TechBank"
      alert("The amount is not credited.Kindly Try Again")
      this.router.navigate(['deposit'])
  
    }
  }
  clear()
  {
    this.is_hidden=true
  }
  gotoHome()
  {
    this.router.navigate(['home'])
  }


}

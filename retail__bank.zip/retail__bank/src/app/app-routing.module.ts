import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { AccountsummaryComponent } from './accountsummary/accountsummary.component';
import { AdminComponent } from './admin/admin.component';
import { DepcomComponent } from './depcom/depcom.component';
import { DepositComponent } from './deposit/deposit.component';
import { DepositstatusComponent } from './depositstatus/depositstatus.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { LogoutComponent } from './logout/logout.component';
import { RegisterComponent } from './register/register.component';
import { SendMoneyComponent } from './send-money/send-money.component';
import { SettingComponent } from './setting/setting.component';
import { StatusComponent } from './status/status.component';
import { AuthGuardGuard } from './auth-guard.guard';

const routes: Routes = [
  {path:'login',component:LoginpageComponent},
  {path:'sendMoney',component:SendMoneyComponent},
  {path:'about-us',component:AboutUsComponent},
  {path:'deposit',component:DepositComponent},
  {path:'accountsummary',component:AccountsummaryComponent},
  {path:'logout',component:LogoutComponent},
  {path:'depcom',component:DepcomComponent},
  {path:'register',component:RegisterComponent},
  {path:'status',component:StatusComponent},
  {path:'setting',component:SettingComponent},
  {path:'home',component:HomeComponent},
  {path:'depositstatus',component:DepositstatusComponent},
  {path:'admin',component:AdminComponent,canActivate:[AuthGuardGuard]}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-depcom',
  templateUrl: './depcom.component.html',
  styleUrls: ['./depcom.component.css']
})
export class DepcomComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  gotoHome()
  {
    this.router.navigate(['home'])
  }
}

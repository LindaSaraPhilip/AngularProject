import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private router:Router,private fb:FormBuilder) { }
  gotoregister()
  {
    this.router.navigate(['register'])

  }

  ngOnInit(): void {
  }
  data={
    email:'',
    password:''
  }
 
  
  gotohome()
  {
    
    this.router.navigate(['home'])
  }
  submit=false
  registrationForm=this.fb.group(
  {
    email:['',[Validators.required,Validators.email]],
    password:['',Validators.required]
  })
  get f()
  {
    return this.registrationForm.controls;
  }
  onSubmit()
  {
    this.submit=true
    console.log("Clicked")
    console.log("f",this.f);
    
    if(this.submit==true )
    {
      this.router.navigate(['home'])
    }
    else
    {
      alert("you cannot access TechBank without filling required fields")
    }
  }

  
}

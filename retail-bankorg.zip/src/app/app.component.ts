import { Component } from '@angular/core';
import { FormBuilder,Validators  } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'retail-bank';

  
    presentDate = new Date(); 
 constructor(private fb:FormBuilder,public router:Router)
  {

  }
  submit=false
  registrationForm=this.fb.group(
  {
    firstName:['hello',Validators.required],
    lastName:['',Validators.required],
    phone:['',[Validators.required,Validators.pattern('[0-9]{10}')]],
    email:['',[Validators.required,Validators.email]]
  })
  
  ngOnInit()
  {
    
    
  }
  get f()
  {
    return this.registrationForm.controls;
  }
  onSubmit()
  {
    this.submit=true
    console.log("Clicked")
    console.log("f",this.f);
  }
  gotoadmin()
  {
    alert("user cannot access admin  ")
  }
  
}



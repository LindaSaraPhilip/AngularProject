import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  psw=''

  constructor(private router:Router,private fb:FormBuilder) { }

  ngOnInit(): void {
  }
  gotoregister()
  {
    this.router.navigate(['register'])

  }
  data={
    email:'',
    password:''
  }
 
  
  gotologin()
  {
    
    this.router.navigate(['login'])
  }
  submit=false
  registrationForm=this.fb.group(
  {
    email:['',[Validators.required,Validators.email]],
    password:['',Validators.required]
  })
  get f()
  {
    return this.registrationForm.controls;
  }
  onSubmit()
  {
    this.submit=true
    console.log("Clicked")
    console.log("f",this.f);
    
    if(this.submit==true )
    {
      this.router.navigate(['home'])
    }
    else
    {
      alert("you cannot access TechBank without filling required fields")
    }
  }

  
  
  

  
}

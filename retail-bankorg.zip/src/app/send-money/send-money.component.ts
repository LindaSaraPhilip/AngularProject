import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-send-money',
  templateUrl: './send-money.component.html',
  styleUrls: ['./send-money.component.css']
})
export class SendMoneyComponent implements OnInit {

  constructor(private fb:FormBuilder,private router:Router)
  {

  }
  submit=false
  registrationForm=this.fb.group(
  {
    Name:['',Validators.required],
    account:['',Validators.required],
    branch:['',Validators.required],
    bank:['',Validators.required],
    ifsc:['',Validators.required],
    email:['',[Validators.required,Validators.email]],
    amount:['',Validators.required],
  })
  
  ngOnInit()
  {
    
    
  }
  get f()
  {
    return this.registrationForm.controls;
  }
  onSubmit()
  {
    this.submit=true
    console.log("Clicked")
    console.log("f",this.f);
    

    //alert("Money Transfer - SUCCESS")
  }
  gotoHome()
  {
    this.router.navigate(['home'])
  }
  gotoStatus()
  {
    
    if(this.registrationForm.valid)
    {
    confirm("Do you want to save changes?")
    if (confirm("Do you want to save changes?") === true) 
    {
      alert("Data saved successfully!  ");
      this.router.navigate(['depcom'])
    } 
    else
  {
    confirm("Save Cancelled.Money Transfer Unsuccessful");
   
      this.router.navigate(['home'])
    
  }
}
else{
  alert("Enter Required Fields");
}
  }

  }
  



import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DepcomComponent } from './depcom.component';

describe('DepcomComponent', () => {
  let component: DepcomComponent;
  let fixture: ComponentFixture<DepcomComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DepcomComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DepcomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }   from '@angular/forms'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SendMoneyComponent } from './send-money/send-money.component';
import { DepositComponent } from './deposit/deposit.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { LoginComponent } from './login/login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { AccountsummaryComponent } from './accountsummary/accountsummary.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { DepcomComponent } from './depcom/depcom.component';
import { LogoutComponent } from './logout/logout.component';
import { RegisterComponent } from './register/register.component';
import { StatusComponent } from './status/status.component';
import { SettingComponent } from './setting/setting.component';
import { HomeComponent } from './home/home.component';
import { DepositstatusComponent } from './depositstatus/depositstatus.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    SendMoneyComponent,
    DepositComponent,
    AboutUsComponent,
    LoginComponent,
    AccountsummaryComponent,
    LoginpageComponent,
    DepcomComponent,
    LogoutComponent,
    RegisterComponent,
    StatusComponent,
    SettingComponent,
    HomeComponent,
    DepositstatusComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

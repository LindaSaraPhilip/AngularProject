import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private fb:FormBuilder)
  {

  }
  submit=false
  registrationForm=this.fb.group(
  {
    firstName:['',Validators.required],
    lastName:['',Validators.required],
    phone:['',[Validators.required,Validators.pattern('[0-9]{10}')]],
    email:['',[Validators.required,Validators.email]]
  })
  
  ngOnInit()
  {
    
    
  }
  get f()
  {
    return this.registrationForm.controls;
  }
  onSubmit()
  {
    this.submit=true
    console.log("Clicked")
    console.log("f",this.f);
    alert("you cannot access TechBank without filling required fields")








   
  }
}


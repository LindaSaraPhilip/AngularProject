import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DepositstatusComponent } from './depositstatus.component';

describe('DepositstatusComponent', () => {
  let component: DepositstatusComponent;
  let fixture: ComponentFixture<DepositstatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DepositstatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DepositstatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
